<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Document</title>


	<link rel="stylesheet" type="text/css" href="./pages/css/formstyle.css">

</head>

<body>
	<div class="hr-heading">

		<h2>SCHEDULE TRAINING</h2>

	</div>

	<form>
		<table class="hr-table">
			<tr>
				<td>Training Name</td>
				<td><input type="text" id="trainingname" name="trainingname"></td>
			</tr>
			<tr>
				<td>Description</td>
				<td><input type="text" id="desc" name="desc"></td>
			</tr>

			<tr>
				<td>Date</td>
				<td><input type="date" id="schdaytime" name="schdaydate"></td>
			</tr>
			<tr>
				<td>Venue</td>
				<td><input type="text" id="venue" name="venue"></td>
			</tr>
			<tr>
				<td>Time</td>
				<td><input type="time" name="schdaytime"></td>
			</tr>

			<tr>
				<td>Assigned Employees</td>
				<td><input type="text" id="employees" name="employees"></td>
			</tr>

			<tr align="center">
				<td> <button class="button2">Cancel</button></td>
				<td><button class="button">Save</button></td>
			</tr>

		</table>

	</form>

</body>

</html>