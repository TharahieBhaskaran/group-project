<html>
<head>
<link rel="stylesheet" type="text/css" href="pages/css/formstyle.css">
</head>
<body>

<h2>VIEW EMPLOYEE</h2><br>
	
<table id="table1">
  <tr>
  	<th>EmpID</th>
	<th>Full Name</th>
	<th>Position Applied</th>
	<th>Department</th>  	 
	<th>Email</th>
	
  </tr>
  <tr>
	  <td>EM0001</td>
	<td>Ms.Robin Jack</td>
	  <th>Programmer</th>
	<td>Software Development</td>  
	<td> robinjack@gmail.com</td>
	
 </tr>
 <tr>
	 
    <td>EM0002</td>
	<td>Mr.Sam Peter</td>
	 <td>Accountant</td>
	<td>Accounting</td>  
	<td>sampeter@gmail.com</td>
	
 

</table>


</body>
</html>
