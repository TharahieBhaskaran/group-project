<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>

  <link rel="stylesheet" type="text/css" href="./pages/css/formstyle.css">

</head>

<body>
  <div class="hr-heading">

    <h2>Employee Job Summary</h2>

  </div>

  <table class="hr-table">
    <tr>
      <th>Department</th>
      <th>Job Title</th>
      <th>Total count</th>

    </tr>
    <tr>
      <td>IT</td>
      <td>Programmer</td>
      <td>6</td>
    </tr>
    <tr>
      <td>Accounting</td>
      <td>Assistant Accountant</td>
      <td>7</td>
    </tr>

  </table>



</body>

</html>