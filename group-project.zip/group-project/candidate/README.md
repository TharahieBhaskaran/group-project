https://docs.google.com/document/d/19cL-__igN69As_Fuq0jkuymnzgmejmfd-O47cISqAOI/edit?usp=drivesdk
