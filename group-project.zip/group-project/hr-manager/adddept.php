<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
	
<link rel="stylesheet" type="text/css" href="css/formstyle.css">
	
</head>

<body>
    <div class="dashboard">

        <h2> Department</h2>
		<br><br>


    </div>

	<table id="table1">
  <tr>
	<th>Department ID</th>
	  <th>Department Name</th>
	<th>Update</th>	
	<th>Delete</th>
  </tr>
 
		<tr>
	<td>001</td>
			 <td>Human Resource</td>
			<td><button class="button2">Update</button></td>
	<td><button class="button">Delete</button></td>
		</tr>
			
		<tr>
	  	<td>002</td>  
	  <td>Accounting</td>
			<td><button class="button2">Update</button></td>
			<td><button class="button">Delete</button></td>	  
 </tr>
 
 
 </table>
	
	
	
</body>

</html>