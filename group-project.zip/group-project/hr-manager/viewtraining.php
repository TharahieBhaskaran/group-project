<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
	
	<link rel="stylesheet" type="text/css" href="css/formstyle.css">
</head>

<body>
    <div class="dashboard">

        <h2>Training Details</h2>

    </div>

	<table id="table1">
  <tr>
  	<th>Training Name</th>
	<th>Description</th>
	<th>Date</th>  
	<th>Venue</th>
	<th>Time</th>
	<th>Assigned Employees</th>
  </tr>
  <tr>
    <td>Quick Books Training</td>
	<td>Training on entering transactionw</td>
	<td>10/11/2021</td>  
	<td> World Trade Center</td>
	<td>12:00am-14:00pm</td>
	<td>EM0004,EM010,EM011</td>
	<td><button class="button2">Update</button></td>
	<td><button class="button">Delete</button></td>
 </tr>
 </table>

</body>

</html>