<html>

<head>
  <link rel="stylesheet" type="text/css" href="pages/css/formstyle.css">
</head>

<body>

   
<td><button class="hr-button" onclick="window.location.href='pages/adduser.php';">
      Signup Employee</button></td>
	
 </body>

</html>