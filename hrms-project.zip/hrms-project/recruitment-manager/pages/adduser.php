<?php

$servername='localhost';
$username='root';
$password='';
$dbname = "2102_test";
$conn=mysqli_connect($servername,$username,$password,"$dbname");
if(!$conn){
  die('Could not Connect My Sql:' .mysql_error());
}


require "../../../assets/mailer/Exception.php";
require "../../../assets/mailer/PHPMailer.php";
require "../../../assets/mailer/SMTP.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMP;


if (isset($_POST['submit'])) {
	
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

mysqli_query($conn,"UPDATE candidate set password = '" . $password . "' WHERE email='" . $_POST['email'] . "'");
$message = "Record Modified Successfully";

	
	$mail = new PHPMailer();

        $mail->isSMTP();
        $mail->Host = "smtp.gmail.com";
        $mail->SMTPAuth = "true";
        $mail->SMTPSecure = "tls";
        $mail->Port = "587";
        $mail->Username = "hrproj2021@gmail.com";
        $mail->Password = "samsung@25";
        $mail->setFrom("hrproj2021@gmail.com", "NexHRM");
        $mail->isHTML(true);
        $mail->Subject = "Employee Registration";
		$ManagerEmail="hrproj2021@gmail.com";
        $mail->Body = "Your user email is " . $_POST['email'] . " and Password is " .$_POST['password'] ;
        $mail->addAddress($ManagerEmail);
        //$mail->send();
        if ($mail->send()) {
            echo "Send Success";
            # code...
        } else {
            echo "sending Fail";
        }

        $mail->smtpClose();
  
}

?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>EMPLOYEE REGISTRATION FORM</title>

    <link rel="stylesheet" type="text/css" href="css/style1.css" />
</head>

<body>
    <div class="container">
        <div class="row">
             <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
				
				<div class="dashboard">

        		<h2>Employee Registration</h2>

    			</div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <td><input type="text" name="email" id="email"></td>

                        <div class="form-group">
                            <label>Password</label>
                            <td><input type="password" name="password" id="password"></td>


                        <div class="form-group">
                             <label>Confirm Password</label>
                             <td><input type="password" name="cpassword" id="cpassword"></td>
                     <input type="submit" value="Submit" name="submit">
						
              </form>
            </div>
        </div>
   </body>

</html>