-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 25, 2021 at 07:23 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2102_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate`
--

CREATE TABLE `candidate` (
  `candidateid` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `nationality` text NOT NULL,
  `nicno` varchar(20) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `telephone` varchar(12) NOT NULL,
  `address` varchar(50) NOT NULL,
  `department` varchar(20) NOT NULL,
  `expsalary` float NOT NULL,
  `position` varchar(20) NOT NULL,
  `wrkschedule` varchar(25) NOT NULL,
  `eduqual` varchar(50) NOT NULL,
  `profqual` varchar(50) NOT NULL,
  `workcomp` varchar(20) NOT NULL,
  `workdesig` varchar(20) NOT NULL,
  `workfrom` date DEFAULT NULL,
  `workto` date DEFAULT NULL,
  `recmgr_assignemail` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userRole` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `isDelete` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `candidate`
--

INSERT INTO `candidate` (`candidateid`, `firstname`, `lastname`, `fullname`, `dob`, `gender`, `nationality`, `nicno`, `contactno`, `email`, `telephone`, `address`, `department`, `expsalary`, `position`, `wrkschedule`, `eduqual`, `profqual`, `workcomp`, `workdesig`, `workfrom`, `workto`, `recmgr_assignemail`, `password`, `userRole`, `status`, `isDelete`) VALUES
(87, 'Kate', 'Peter', 'Kate Peter', '1999-10-04', 'Female', 'srilankan', '993456789V', '0710787877', 'katepeter@gmail.com', '0710787877', '28, Richard Street, Kollupitiya, Colombo - 03', 'IT', 50000, 'Manager', '', 'B.Sc in Computer Science', '', '', '', '0000-00-00', '0000-00-00', 'katepeter@gmail.com', '$2y$10$BBRUgv3v89YI3iMOEzg9z.RHDijBDyQCSOYMscpwMRA', 'employee', 'selected', 1),
(88, 'Amila', 'Amaratunge', 'Amila Amaratunge', '1998-10-08', '', 'srilankan', '983456789V', '0710777777', 'amila@gmail.com', '2567904786', 'abc street', 'Marketing', 40000, 'Sales Executive', '', 'BBA in Marketing', 'CIMA', '', '', '0000-00-00', '0000-00-00', 'amila@gmail.com', '', 'employee', 'selected', 1),
(89, 'Jill', 'Samuel', 'Jill Samuel', '1999-11-03', 'Female', 'srilankan', '990756789V', '0710666689', 'jillsamuel@gmail.com', '0710666689', '20, White Street, Kollupitiya, Colombo - 03', 'IT', 50000, 'Manager', '', 'BSc in Computer Science', '', '', '', '0000-00-00', '0000-00-00', 'jillsamuel@gmail.com', '', 'employee', 'selected', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`candidateid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `candidateid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
